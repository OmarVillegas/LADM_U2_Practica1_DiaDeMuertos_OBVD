package com.example.ladm_u2_practica1_diademuertos_obvd

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View

class Lienzo(p: MainActivity) : View(p) {

    var activo  = false
    var cuadro = Figura(0,500,1200,1000)

    var murcielago1 = Imagen(this, 50f,150f, R.drawable.murcielago)
    var murcielago2 = Imagen(this, 450f,150f, R.drawable.murcielago)
    var murcielago3 = Imagen(this, 850f,150f, R.drawable.murcielago)

    var murcielago4 = Imagen(this, 50f,1600f, R.drawable.murcielago)
    var murcielago5 = Imagen(this, 450f,1600f, R.drawable.murcielago)
    var murcielago6 = Imagen(this, 850f,1600f, R.drawable.murcielago)

    var grave1 = Imagen(this, 50f, 700f, R.drawable.grave)
    var grave2 = Imagen(this, 450f,700f, R.drawable.grave)
    var grave3 = Imagen(this, 850f,700f, R.drawable.grave)

    var grave4 = Imagen(this, 50f,900f, R.drawable.grave)
    var grave5 = Imagen(this, 450f,900f, R.drawable.grave)
    var grave6 = Imagen(this, 850f,900f, R.drawable.grave)

    var grave7 = Imagen(this, 50f,1100f, R.drawable.grave)
    var grave8 = Imagen(this, 450f,1100f, R.drawable.grave)
    var grave9 = Imagen(this, 850f,1100f, R.drawable.grave)

    var xC=400f
    var yC=800f
    var incrementoX=10

    val timer = object : CountDownTimer(30,100){
        override fun onTick(p0: Long) {
            xC+=incrementoX
            if (xC<=100 || xC>=850){
                incrementoX*=-1
            }
            invalidate()
        }
        override fun onFinish() {
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint = Paint()
        //fondo amarillo
        canvas.drawColor(Color.rgb(255, 255, 0))

        //cuadro negro
        paint.color = Color.rgb(0, 0, 0)
        cuadro.pintar(canvas, paint)

        //dibujar tumbas
        grave1.dibujar(canvas)
        grave2.dibujar(canvas)
        grave3.dibujar(canvas)
        grave4.dibujar(canvas)
        grave5.dibujar(canvas)
        grave6.dibujar(canvas)
        grave7.dibujar(canvas)
        grave8.dibujar(canvas)
        grave9.dibujar(canvas)

        //dibujar murcielago
        murcielago1.dibujar(canvas)
        murcielago2.dibujar(canvas)
        murcielago3.dibujar(canvas)
        murcielago4.dibujar(canvas)
        murcielago5.dibujar(canvas)
        murcielago6.dibujar(canvas)

        //esqueleto
        var esqueleto = Imagen(this, xC-300, yC-200,  R.drawable.esqueleto)
        esqueleto.dibujar(canvas)

    }//OnDrawn

    //event.action para iniciar el movimiento de la calavera
    override fun onTouchEvent(event: MotionEvent): Boolean {

        if (event.action == MotionEvent.ACTION_DOWN) {
            //Entra si se presiona
            if (activo == false) {
                timer.start()
                activo = true
            }
        }
        if (event.action == MotionEvent.ACTION_MOVE) {

        }
        if (event.action == MotionEvent.ACTION_UP) {

        }
        invalidate()
        return true
    }

}